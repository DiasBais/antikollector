<template>
    <div>Hello Vue!</div>
</template>

<script>
export default {
    name: 'Test'
}
</script>
